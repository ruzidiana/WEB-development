let admin, name = "John"; 
admin = name;
alert(admin);